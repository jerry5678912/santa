#!/bin/zsh
set -euo pipefail
cd "${0:A:h}"
mkdir -p artifacts
/usr/bin/clang -O2 -Wall -Wextra payload.c -o artifacts/payload
/usr/bin/clang -O2 -Wall -Wextra benign.c -o artifacts/benign
/usr/bin/clang -O2 -Wall -Wextra race.c -o artifacts/race
for binary in artifacts/payload artifacts/benign artifacts/race; do
  /usr/bin/codesign --force --sign - "$binary"
done
/usr/bin/shasum -a 256 artifacts/benign artifacts/race
print 'Administrator: add BINARY ALLOW rules for benign and race hashes, then lock the VM.'
print 'Do not allow the payload hash.'
