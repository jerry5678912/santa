#!/bin/zsh
set -euo pipefail
cd "${0:A:h}"
mkdir -p artifacts
/usr/bin/clang -O2 -Wall -Wextra payload.c -o artifacts/payload
app='artifacts/SantaRace.app'
/bin/rm -rf "$app"
/bin/mkdir -p "$app/Contents/MacOS"
/usr/bin/clang -O2 -Wall -Wextra race.c -o "$app/Contents/MacOS/SantaRace"
/bin/cat > "$app/Contents/Info.plist" <<'PLIST'
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0"><dict>
  <key>CFBundleExecutable</key><string>SantaRace</string>
  <key>CFBundleIdentifier</key><string>test.santa.SantaRace</string>
  <key>CFBundleName</key><string>SantaRace</string>
  <key>CFBundlePackageType</key><string>APPL</string>
  <key>CFBundleVersion</key><string>1</string>
</dict></plist>
PLIST
/usr/bin/codesign --force --sign - artifacts/payload
/usr/bin/codesign --force --sign - "$app"
/usr/bin/shasum -a 256 "$app/Contents/MacOS/SantaRace"
print 'Administrator: allow the SantaRace.app test application, then lock the VM.'
print 'Do not allow the payload hash.'
