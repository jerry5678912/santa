#!/bin/zsh
set -euo pipefail
/usr/bin/pkill -f '/tmp/santa-overload\.' 2>/dev/null || true
/bin/rm -f /tmp/santa-poc-payload-ran /tmp/santa-poc-benign-ran
/usr/bin/find /tmp -maxdepth 1 -type d \( -name 'santa-toctou.*' -o -name 'santa-overload.*' \) -exec /bin/rm -rf {} +
print 'Local PoC files removed. Ask the image administrator to remove the SantaRace.app allow rule.'
