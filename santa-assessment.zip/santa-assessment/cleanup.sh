#!/bin/zsh
set -euo pipefail
cd "${0:A:h}"
/usr/bin/pkill -f '/\.santa-overload\.' 2>/dev/null || true
/bin/rm -f /tmp/santa-poc-payload-ran /tmp/santa-poc-benign-ran
/usr/bin/find "$PWD" -maxdepth 1 -type d \( -name '.santa-toctou.*' -o -name '.santa-overload.*' \) -exec /bin/rm -rf {} +
print 'Local PoC files removed. Ask the image administrator to remove the SantaRace.app allow rule.'
