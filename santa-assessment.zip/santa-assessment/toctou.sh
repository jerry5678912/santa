#!/bin/zsh
set -euo pipefail
cd "${0:A:h}"
test -x artifacts/payload
test -x artifacts/SantaRace.app/Contents/MacOS/SantaRace

work="$(/usr/bin/mktemp -d "$PWD/.santa-toctou.XXXXXX")"
trap '/bin/rm -rf "$work"' EXIT
/bin/cp artifacts/payload "$work/slot"
/bin/cp artifacts/SantaRace.app/Contents/MacOS/SantaRace "$work/other"
/bin/chmod 755 "$work/slot" "$work/other"
/bin/rm -f /tmp/santa-poc-payload-ran

print '[control] unknown payload must be blocked'
"$work/slot" >/dev/null 2>&1 || true
if [[ -e /tmp/santa-poc-payload-ran ]]; then
  print 'INVALID TEST: payload already executes without the race'
  exit 2
fi

print '[race] attempting pathname/vnode split as the unprivileged tester'
artifacts/SantaRace.app/Contents/MacOS/SantaRace "$work/slot" "$work/other" || true
if [[ ! -e /tmp/santa-poc-payload-ran ]]; then
  print 'NOT REPRODUCIBLE: race did not execute payload in this run'
  exit 1
fi

print '[verification] swaps are stopped; direct payload execution should still be blocked'
/bin/rm -f /tmp/santa-poc-payload-ran
"$work/slot" >/dev/null 2>&1 || true
if [[ -e /tmp/santa-poc-payload-ran ]]; then
  print 'CONFIRMED: payload executed directly after race; wrong allow was cached'
  exit 0
fi

print 'PARTIAL OBSERVATION: race executed payload, but persistent cache allow was not observed'
exit 3
