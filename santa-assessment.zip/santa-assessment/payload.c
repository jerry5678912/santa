#include <fcntl.h>
#include <unistd.h>

int main(void) {
  const char marker[] = "payload executed\n";
  int fd = open("/tmp/santa-poc-payload-ran", O_WRONLY | O_CREAT | O_APPEND, 0600);
  if (fd < 0) return 2;
  ssize_t n = write(fd, marker, sizeof(marker) - 1);
  close(fd);
  return n == (ssize_t)(sizeof(marker) - 1) ? 0 : 3;
}
