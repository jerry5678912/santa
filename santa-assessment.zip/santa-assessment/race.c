#include <errno.h>
#include <fcntl.h>
#include <signal.h>
#include <stdio.h>
#include <stdlib.h>
#include <sys/stat.h>
#include <sys/wait.h>
#include <time.h>
#include <unistd.h>

static const char *marker = "/tmp/santa-poc-payload-ran";
static const char *benign_marker = "/tmp/santa-poc-benign-ran";

static int run_benign(void) {
  const char message[] = "trusted test app executed\n";
  int fd = open(benign_marker, O_WRONLY | O_CREAT | O_APPEND, 0600);
  if (fd < 0) return 2;
  ssize_t n = write(fd, message, sizeof(message) - 1);
  close(fd);
  return n == (ssize_t)(sizeof(message) - 1) ? 0 : 3;
}

static int run_one(const char *slot, const char *other, long delay_ns) {
  int gate[2];
  if (pipe(gate) != 0) return -1;
  pid_t child = fork();
  if (child < 0) return -1;
  if (child == 0) {
    char c;
    close(gate[1]);
    if (read(gate[0], &c, 1) != 1) _exit(120);
    close(gate[0]);
    char *const argv[] = {(char *)slot, NULL};
    execv(slot, argv);
    _exit(errno == EPERM ? 121 : 122);
  }

  close(gate[0]);
  if (write(gate[1], "x", 1) != 1) return -1;
  close(gate[1]);

  struct timespec ts = {.tv_sec = delay_ns / 1000000000L,
                        .tv_nsec = delay_ns % 1000000000L};
  nanosleep(&ts, NULL);
  if (renamex_np(slot, other, RENAME_SWAP) != 0) {
    perror("renamex_np swap-in");
    kill(child, SIGKILL);
    waitpid(child, NULL, 0);
    return -1;
  }

  int status = 0;
  waitpid(child, &status, 0);
  if (renamex_np(slot, other, RENAME_SWAP) != 0) {
    perror("renamex_np restore");
    return -1;
  }
  return access(marker, F_OK) == 0 ? 1 : 0;
}

int main(int argc, char **argv) {
  /* With no arguments this same executable is the trusted benign fixture. */
  if (argc == 1) return run_benign();

  if (argc != 3) {
    fprintf(stderr, "usage: %s [PAYLOAD_SLOT ALLOWLISTED_OTHER]\n", argv[0]);
    return 64;
  }
  unlink(marker);

  /* Sweep 0..5 ms. Repeat each delay to absorb scheduler variance. */
  for (long delay = 0; delay <= 5000000L; delay += 5000L) {
    for (int trial = 0; trial < 12; ++trial) {
      int r = run_one(argv[1], argv[2], delay);
      if (r < 0) return 2;
      if (r > 0) {
        printf("RACE_SUCCEEDED delay_ns=%ld trial=%d\n", delay, trial);
        return 0;
      }
    }
  }
  puts("RACE_NOT_OBSERVED");
  return 1;
}
