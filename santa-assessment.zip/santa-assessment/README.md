# Santa enforcement-failure assessment

Target: `jerry5678912/santa` commit `6777461a09200c0385ad2b71dd30264fee45b849`

Assessment host: Linux. Santa's Endpoint Security clients require macOS, so no
candidate below is classified CONFIRMED. Run the supplied harnesses in a
disposable macOS VM with the production release build and the required managed
configuration. Do not run them on a production endpoint.

Santa's normal unknown-binary control is pre-execution denial through Endpoint
Security, rather than post-launch termination. Its NATS `KillingMachine` is a
separate administrator-commanded process-kill facility. The assessment maps
the requested "automatic untrusted-process termination" condition to
fail-closed AUTH_EXEC denial in Lockdown mode; no claim below depends on local
administrator access or disabling that control.

## Required managed configuration

The test image must be prepared by its administrator, then handed to a tester
who has no administrator credentials or console access:

- `ClientMode = LOCKDOWN`
- `FailClosed = true`
- automatic enforcement enabled and the system extension healthy
- no allowed-path rule covering the test directory
- a binary SHA-256 allow rule for `artifacts/benign`
- a binary SHA-256 allow rule for `artifacts/race`

Compile the two allowlisted artifacts first with `./prepare.sh`. The image
administrator can then add their printed SHA-256 values to central policy and
lock the machine. The unprivileged tester runs `./toctou.sh` and
`./overload.sh`; neither command changes Santa configuration.

## L-1: pathname/vnode split permits inspection of a different executable

Classification: **LIKELY**, high severity, protection failure with cache
persistence across later executions.

`SNTFileInfo` copies `st_dev`, `st_ino`, and size from the Endpoint Security
`es_file_t`, but opens `es_file_t.path` later. It never `fstat()`s the opened
descriptor or compares the descriptor's vnode to the event vnode. Hashing and
code-signature inspection therefore operate on whichever file occupies that
path at `open()` time. The final authorization and local cache key still refer
to the original ES vnode.

Relevant source:

- `Source/common/SNTFileInfo.mm:79-80` accepts ES metadata.
- `Source/common/SNTFileInfo.mm:109-121` stores the ES vnode/size but reopens the
  path.
- `Source/common/SNTFileInfo.mm:156-218` hashes the reopened descriptor.
- `Source/santad/SNTExecutionController.mm:333-371` makes policy from that
  object, then associates the decision with the original target vnode.
- `Source/santad/EventProviders/SNTEndpointSecurityAuthorizer.mm:263-267`
  returns the cacheable allow to Endpoint Security.

Run `./toctou.sh`. It first proves that the payload is blocked without the
race. The harness then atomically swaps an allowlisted benign binary into the
payload pathname after `execve()` begins. Success requires all three checks:

1. the pre-race payload does not create `/tmp/santa-poc-payload-ran`;
2. a race attempt creates the marker, proving the original payload executed;
3. after swaps stop and the pathname contains only the payload, a direct
   execution creates the marker again, proving the wrong allow was cached for
   the payload vnode.

Expected secure result: the race never creates the payload marker and the
post-race direct execution remains blocked.

Cleanup: `./cleanup.sh`. The image administrator must also remove the two test
allow rules from central policy.

Suggested repair: open the event target by a kernel-bound mechanism if one is
available. At minimum, `fstat()` the opened descriptor and require its device,
inode, mode, and size to match the ES event before hashing; recheck after the
read, treat mismatch as deny, and never cache that result. A descriptor opened
by pathname still leaves a replacement window before `open()`, so the strongest
fix needs an identity source tied to the authorized vnode.

## L-2: unbounded full-file hashing can exhaust authorization workers

Classification: **LIKELY**, high severity, partial/complete availability
failure under fail-closed enforcement.

Every uncached executable is hashed synchronously to its full ES-reported size.
There is no executable-size cap (`SNTExecutionController.mm:350-351` contains a
TODO), while authorization work is dispatched to a concurrent queue. A standard
user can create many distinct sparse, executable Mach-O files with very large
logical sizes and issue concurrent execs. Deadline responders deny each event,
but the hashing workers continue until their reads finish. Fresh, legitimately
allowlisted binaries can then miss their own deadlines and be denied.

Run `./overload.sh`. It creates fresh vnodes for an allowlisted benign fixture,
records a sequential baseline, starts concurrent large sparse unknown binaries,
then launches fresh allowlisted probes. The test reports a candidate failure
only if the baseline succeeds and one or more allowlisted probes fail to run.
Correlate with Santa's `deadline reached` logs.

Expected secure result: all allowlisted probes run with latency close to the
baseline, and santad remains responsive. Actual vulnerable result: probes are
denied or delayed until ES deadlines while the sparse-file workers continue.

Suggested repair: bind work to the ES deadline, cancel hashing after the
default response, bound concurrent expensive inspections, and use a byte/time
budget with a fail-closed result. A file-size cap alone needs careful policy so
large legitimate applications remain usable.

## L-3: critical Endpoint Security subscription failures are ignored

Classification: **LIKELY**, high severity, silent startup/recovery failure.

`subscribeAndClearCache` returns failure, but the authorizer's `enable` method
discards it and marks itself enabled. Startup then continues to tamper,
monitoring, and device clients without a readiness assertion. The same pattern
appears in tamper resistance and device management.

Relevant source:

- `Source/common/es/SNTEndpointSecurityClient.mm:198-207` returns the ES errors.
- `Source/santad/EventProviders/SNTEndpointSecurityAuthorizer.mm:273-278`
  discards the result.
- `Source/santad/Santad.mm:861-883` continues startup.

Validation requires an instrumented macOS build whose `EndpointSecurityAPI`
returns false once from `Subscribe` and once from `ClearCache`. Independently
attempt an unknown binary after each injected failure. A finding is confirmed
only if santad stays healthy/status-active while the binary executes or a stale
allow remains effective. A unit assertion that `enable` returns is supporting
evidence, not sufficient confirmation by itself.

Suggested repair: make every enforcement client's `enable` return a status;
abort startup (so launchd retries) if AUTH subscriptions, muting/inversion, or
cache clearing fails. Expose per-client subscription health in status and retry
recoverable failures with a bounded backoff.

## L-4: expired-deadline arithmetic underflows

Classification: **THEORETICAL**, medium severity, recovery/intermittent failure.

`computeBudgetForDeadline` subtracts two unsigned Mach absolute times before
conversion. If callback delivery or scheduling occurs after the deadline,
`deadline - currentTime` wraps to a large value and schedules the fallback far
in the future. Existing tests cover only future deadlines.

Relevant source: `Source/common/es/SNTEndpointSecurityClient.mm:305-320`.

Validate with an instrumented delayed callback and an actual AUTH_EXEC request,
then verify both the ES response result and subsequent cache state. The unit
test should also directly pass `currentTime > deadline` and require a zero or
immediate budget.

Suggested repair: check `currentTime >= deadline` before subtraction and return
zero. Use checked conversion and clamp the final budget to `[0, remaining]`.

## Status summary

- CONFIRMED: 0
- LIKELY: 3
- THEORETICAL: 1
- NOT REPRODUCIBLE: 0

The absence of CONFIRMED findings is an environment limitation, not a claim
that the candidates are safe. Confirmation requires the supplied macOS tests
to observe the independent protection checks described above.
